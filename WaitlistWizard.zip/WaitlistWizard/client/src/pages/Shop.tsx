import { useToast } from '@/hooks/use-toast';
import { Link, useLocation } from 'wouter';
import { useCart } from '@/lib/cartContext';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowRight, ShoppingCart } from 'lucide-react';

// Product type definition
interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
}

export default function Shop() {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const { addItem, totalItems } = useCart();
  
  // Sample product data
  const products: Product[] = [
    {
      id: "1",
      name: "Berhan Smart Stick",
      description: "Advanced AI-powered stick for visually impaired individuals. Features obstacle detection, navigation assistance, and voice guidance.",
      price: 18,
      image: "https://placehold.co/600x400/e6f7ff/333333?text=Smart+Stick"
    },
    {
      id: "2",
      name: "Berhan Smart Glasses",
      description: "Enhanced vision support with AI-based object detection. Includes scene description, text recognition, and facial recognition.",
      price: 16,
      image: "https://placehold.co/600x400/e6f7ff/333333?text=Smart+Glasses"
    }
  ];

  const addToCart = (product: Product) => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image
    });
    
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart.`,
    });
  };

  const goToCheckout = () => {
    navigate('/checkout');
  };

  const viewProductDetails = (id: string) => {
    navigate(`/product/${id}`);
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="container mx-auto px-4 py-16 mt-16">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900">Shop Now</h1>
          <div className="relative">
            <Button 
              variant="outline" 
              className="flex items-center gap-2"
              onClick={goToCheckout}
              disabled={totalItems === 0}
            >
              <ShoppingCart className="h-5 w-5 mr-1" />
              Cart <Badge variant="outline">{totalItems}</Badge>
            </Button>
          </div>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8">
          {products.map((product) => (
            <Card key={product.id} className="overflow-hidden transition-all hover:shadow-lg">
              <div 
                className="h-60 overflow-hidden cursor-pointer" 
                onClick={() => viewProductDetails(product.id)}
              >
                <img 
                  src={product.image} 
                  alt={product.name} 
                  className="w-full h-full object-cover transition-transform hover:scale-105"
                />
              </div>
              <CardHeader>
                <CardTitle className="flex justify-between items-center">
                  <Link href={`/product/${product.id}`} className="hover:text-primary transition-colors">
                    {product.name}
                  </Link>
                  <Badge variant="outline">New</Badge>
                </CardTitle>
                <CardDescription>
                  <span className="text-xl font-bold text-primary">${product.price.toLocaleString()}</span>
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">{product.description}</p>
              </CardContent>
              <CardFooter className="flex gap-4">
                <Button onClick={() => addToCart(product)} className="flex-1">
                  Add to Cart
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => viewProductDetails(product.id)} 
                  className="flex-1 flex items-center justify-center gap-2"
                >
                  Details <ArrowRight className="h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
      
      <Footer />
    </div>
  );
}