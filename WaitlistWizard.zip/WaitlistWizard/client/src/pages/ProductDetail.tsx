import { useState } from 'react';
import { useParams, useLocation } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { useCart } from '@/lib/cartContext';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface ProductSpec {
  name: string;
  value: string;
}

interface Product {
  id: string;
  name: string;
  tagline: string;
  description: string;
  longDescription: string;
  price: number;
  image: string;
  gallery: string[];
  specs: ProductSpec[];
}

type ProductDatabase = {
  [key: string]: Product;
};

// Product database (would normally come from API)
const products: ProductDatabase = {
  "1": {
    id: "1",
    name: "Berhan Smart Stick",
    tagline: "Navigate with confidence",
    description: "Advanced AI-powered stick for visually impaired individuals. Features obstacle detection, navigation assistance, and voice guidance.",
    longDescription: `The Berhan Smart Stick is a revolutionary assistive device designed to enhance the mobility and independence of visually impaired individuals. 

Using cutting-edge AI technology, the Smart Stick provides real-time navigation assistance, obstacle detection, and voice guidance to help users navigate their surroundings with confidence.

Key Features:
• Advanced obstacle detection up to 5 meters ahead
• GPS navigation with voice guidance
• Haptic feedback for immediate alerts
• Smartphone app connectivity
• Long-lasting battery (up to 12 hours of continuous use)
• Lightweight, ergonomic design
• Water-resistant construction
• USB-C fast charging

The Berhan Smart Stick is the perfect companion for daily activities, providing a new level of independence and confidence for visually impaired individuals.`,
    price: "$18",
    image: "https://placehold.co/600x400/e6f7ff/333333?text=Smart+Stick",
    gallery: [
      "https://placehold.co/600x400/e6f7ff/333333?text=Smart+Stick+1",
      "https://placehold.co/600x400/e6f7ff/333333?text=Smart+Stick+2",
      "https://placehold.co/600x400/e6f7ff/333333?text=Smart+Stick+3"
    ],
    specs: [
      { name: "Weight", value: "350g" },
      { name: "Dimensions", value: "120cm x 3cm x 3cm" },
      { name: "Battery Life", value: "12 hours" },
      { name: "Charging Time", value: "2 hours" },
      { name: "Detection Range", value: "Up to 5 meters" },
      { name: "Connectivity", value: "Bluetooth 5.0, Wi-Fi" },
      { name: "Compatibility", value: "iOS 12+, Android 8+" },
      { name: "Warranty", value: "2 years" }
    ]
  },
  "2": {
    id: "2",
    name: "Berhan Smart Glasses",
    tagline: "See the world differently",
    description: "Enhanced vision support with AI-based object detection. Includes scene description, text recognition, and facial recognition.",
    longDescription: `The Berhan Smart Glasses represent a breakthrough in assistive technology for the visually impaired. These sleek, lightweight glasses provide enhanced visual information through advanced AI algorithms and discrete audio feedback.

With real-time scene description, text recognition, and facial recognition capabilities, the Smart Glasses help users gain a better understanding of their surroundings and interact more confidently with the world around them.

Key Features:
• AI-powered scene description
• Text recognition and reading
• Facial recognition with name announcements
• Object identification and distance estimation
• Discreet bone-conduction audio
• Smartphone app integration
• 8-hour battery life
• Modern, stylish design
• Prescription lens compatibility

The Berhan Smart Glasses blend seamlessly into everyday life while providing valuable assistance for visually impaired individuals, offering a new way to experience the world.`,
    price: "$16",
    image: "https://placehold.co/600x400/e6f7ff/333333?text=Smart+Glasses",
    gallery: [
      "https://placehold.co/600x400/e6f7ff/333333?text=Smart+Glasses+1",
      "https://placehold.co/600x400/e6f7ff/333333?text=Smart+Glasses+2",
      "https://placehold.co/600x400/e6f7ff/333333?text=Smart+Glasses+3"
    ],
    specs: [
      { name: "Weight", value: "75g" },
      { name: "Dimensions", value: "Standard eyewear size" },
      { name: "Battery Life", value: "8 hours" },
      { name: "Charging Time", value: "1.5 hours" },
      { name: "Camera", value: "12MP, 120° field of view" },
      { name: "Audio", value: "Bone conduction" },
      { name: "Connectivity", value: "Bluetooth 5.0, Wi-Fi" },
      { name: "Compatibility", value: "iOS 12+, Android 8+" },
      { name: "Warranty", value: "2 years" }
    ]
  }
};

export default function ProductDetail() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [quantity, setQuantity] = useState(1);
  const [activeImage, setActiveImage] = useState(0);
  
  // If id is invalid, redirect to shop
  if (!id || !(id in products)) {
    navigate('/shop');
    return null;
  }
  
  const product = products[id];
  
  const { addItem } = useCart();
  
  const addToCart = () => {
    // Add the item to cart for the selected quantity
    for (let i = 0; i < quantity; i++) {
      addItem({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.image
      });
    }
    
    toast({
      title: "Added to cart",
      description: `${quantity} ${product.name} has been added to your cart.`,
    });
  };
  
  const goToCheckout = () => {
    navigate('/checkout');
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="container mx-auto px-4 py-16 mt-16">
        {/* Breadcrumbs */}
        <div className="flex text-sm text-gray-500 mb-8">
          <a href="/" className="hover:text-primary">Home</a>
          <span className="mx-2">/</span>
          <a href="/shop" className="hover:text-primary">Shop</a>
          <span className="mx-2">/</span>
          <span className="text-gray-700">{product.name}</span>
        </div>
        
        <div className="grid md:grid-cols-2 gap-12">
          {/* Product images */}
          <div className="space-y-4">
            <div className="overflow-hidden rounded-lg border border-gray-200 bg-white">
              <img 
                src={product.gallery[activeImage]} 
                alt={product.name} 
                className="w-full h-96 object-contain p-4"
              />
            </div>
            
            <div className="grid grid-cols-3 gap-2">
              {product.gallery.map((image: string, index: number) => (
                <button 
                  key={index}
                  onClick={() => setActiveImage(index)}
                  className={`overflow-hidden rounded-md border ${activeImage === index ? 'border-primary' : 'border-gray-200'}`}
                >
                  <img 
                    src={image} 
                    alt={`${product.name} view ${index + 1}`} 
                    className="w-full h-24 object-cover"
                  />
                </button>
              ))}
            </div>
          </div>
          
          {/* Product details */}
          <div>
            <Badge variant="outline" className="mb-2">New Release</Badge>
            <h1 className="text-3xl font-bold text-gray-900">{product.name}</h1>
            <p className="text-lg text-gray-600 mt-1">{product.tagline}</p>
            
            <div className="mt-8">
              <p className="text-3xl font-bold text-primary">${product.price.toLocaleString()}</p>
              <p className="text-gray-500 mt-1">Free shipping • 30-day returns</p>
            </div>
            
            <div className="mt-8">
              <p className="text-gray-700">{product.description}</p>
            </div>
            
            <div className="mt-8 flex items-center">
              <div className="mr-4">
                <label htmlFor="quantity" className="block text-sm text-gray-700 mb-1">Quantity</label>
                <div className="flex items-center border border-gray-300 rounded-md overflow-hidden">
                  <button 
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-3 py-1 bg-gray-100 hover:bg-gray-200 text-gray-700"
                  >
                    -
                  </button>
                  <input
                    id="quantity"
                    type="number"
                    min="1"
                    value={quantity}
                    onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-12 text-center py-1 border-x border-gray-300"
                  />
                  <button 
                    onClick={() => setQuantity(quantity + 1)}
                    className="px-3 py-1 bg-gray-100 hover:bg-gray-200 text-gray-700"
                  >
                    +
                  </button>
                </div>
              </div>
              
              <div className="flex-1">
                <Button onClick={addToCart} className="w-full mb-2">
                  Add to Cart
                </Button>
                <Button variant="outline" onClick={goToCheckout} className="w-full">
                  Buy Now
                </Button>
              </div>
            </div>
          </div>
        </div>
        
        {/* Product tabs */}
        <div className="mt-16">
          <Tabs defaultValue="description">
            <TabsList className="w-full justify-start border-b">
              <TabsTrigger value="description">Description</TabsTrigger>
              <TabsTrigger value="specifications">Specifications</TabsTrigger>
              <TabsTrigger value="shipping">Shipping & Returns</TabsTrigger>
            </TabsList>
            <TabsContent value="description" className="py-6">
              <div className="prose max-w-none">
                <p className="whitespace-pre-line">{product.longDescription}</p>
              </div>
            </TabsContent>
            <TabsContent value="specifications" className="py-6">
              <Card>
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {product.specs.map((spec: ProductSpec, index: number) => (
                      <div key={index} className="flex justify-between py-2 border-b border-gray-100">
                        <span className="font-medium text-gray-700">{spec.name}</span>
                        <span className="text-gray-600">{spec.value}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="shipping" className="py-6">
              <Card>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-lg font-medium text-gray-900 mb-2">Shipping Policy</h3>
                      <p className="text-gray-700">
                        We offer free standard shipping on all orders. Orders are typically processed and shipped within 1-2 business days. 
                        Delivery times may vary depending on your location, but usually take 3-5 business days after shipping.
                      </p>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-medium text-gray-900 mb-2">Return Policy</h3>
                      <p className="text-gray-700">
                        We offer a 30-day return policy for all products. If you're not satisfied with your purchase, you can return it within 
                        30 days of delivery for a full refund or exchange. Products must be returned in their original packaging and in unused condition.
                      </p>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-medium text-gray-900 mb-2">Warranty</h3>
                      <p className="text-gray-700">
                        All Berhan products come with a 2-year manufacturer's warranty, covering defects in materials and workmanship. 
                        The warranty does not cover damage caused by accidents, misuse, or unauthorized modifications.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
      
      <Footer />
    </div>
  );
}