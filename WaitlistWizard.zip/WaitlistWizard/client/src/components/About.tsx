import { Shield, TrendingUp } from "lucide-react";

export default function About() {
  return (
    <section id="about" className="py-16 md:py-24 bg-gray-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col md:flex-row items-center gap-12">
          <div className="w-full md:w-1/2 order-2 md:order-1">
            <h2 className="text-3xl font-bold mb-6 text-gray-900">About Berhan Stick & Glasses</h2>
            <p className="text-lg text-gray-600 mb-6">
              We are dedicated to providing smart assistive technology for visually impaired individuals. 
              The Berhan Stick & Glasses is designed to enhance mobility and independence through innovative technology.
            </p>
            <p className="text-lg text-gray-600 mb-6">
              Our solution combines AI-powered object detection, real-time audio feedback, and smart navigation 
              to create a comprehensive mobility aid that's lightweight, rechargeable, and easy to use.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 mt-8">
              <div className="flex items-center">
                <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center mr-4">
                  <Shield className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="font-medium text-gray-900">Safe & Reliable</h3>
                  <p className="text-gray-600">Tested for daily navigation</p>
                </div>
              </div>
              <div className="flex items-center">
                <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center mr-4">
                  <TrendingUp className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="font-medium text-gray-900">Innovative</h3>
                  <p className="text-gray-600">AI-powered technology</p>
                </div>
              </div>
            </div>
          </div>
          <div className="w-full md:w-1/2 order-1 md:order-2 animate-slide-up">
            <div className="relative rounded-xl overflow-hidden shadow-xl">
              <div className="w-full h-80 bg-primary-200 flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
