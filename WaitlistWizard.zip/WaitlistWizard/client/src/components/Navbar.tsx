import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { Menu, X, ShoppingCart } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useCart } from "@/lib/cartContext";
import { Badge } from "@/components/ui/badge";

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [location] = useLocation();
  const { totalItems } = useCart();

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  const scrollToSection = (id: string) => {
    setIsMenuOpen(false);
    // Only scroll if we're on the home page
    if (location === "/") {
      const element = document.getElementById(id);
      if (element) {
        const headerOffset = 80;
        const elementPosition = element.getBoundingClientRect().top;
        const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
        
        window.scrollTo({
          top: offsetPosition,
          behavior: "smooth"
        });
      }
    } else {
      // If not on home page, navigate to home and then to section
      window.location.href = `/#${id}`;
    }
  };

  // Handle scroll event to change navbar background
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`fixed w-full top-0 z-50 transition-all duration-300 ${isScrolled || location !== "/" ? 'bg-white shadow-sm' : 'bg-transparent'}`}>
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <span className="text-xl font-bold text-primary">Berhan</span>
            </Link>
          </div>
          
          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={toggleMenu} 
              aria-label="Menu"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
          
          {/* Desktop menu */}
          <nav className="hidden md:flex items-center space-x-6">
            <button 
              onClick={() => scrollToSection('features')}
              className="text-base font-medium text-gray-700 hover:text-primary transition-colors"
            >
              Features
            </button>
            <button
              onClick={() => scrollToSection('about')}
              className="text-base font-medium text-gray-700 hover:text-primary transition-colors"
            >
              About
            </button>
            <Link href="/shop" className="text-base font-medium text-gray-700 hover:text-primary transition-colors">
              Shop
            </Link>
            <Button
              onClick={() => scrollToSection('waitlist')}
              variant={location === "/" ? "default" : "outline"}
              className={location === "/" ? "bg-primary text-white hover:bg-primary/90" : ""}
            >
              Join Waitlist
            </Button>
            <Link href="/checkout">
              <Button variant="outline" size="icon" className="rounded-full relative">
                <ShoppingCart className="h-5 w-5" />
                {totalItems > 0 && (
                  <Badge 
                    className="absolute -top-2 -right-2 bg-primary text-white text-xs" 
                    variant="default"
                  >
                    {totalItems}
                  </Badge>
                )}
              </Button>
            </Link>
          </nav>
        </div>
        
        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden py-2 px-4 bg-white border-t border-gray-200">
            <button
              onClick={() => scrollToSection('features')}
              className="block py-2 text-base font-medium text-gray-700 hover:text-primary"
            >
              Features
            </button>
            <button
              onClick={() => scrollToSection('about')}
              className="block py-2 text-base font-medium text-gray-700 hover:text-primary"
            >
              About
            </button>
            <Link href="/shop" className="block py-2 text-base font-medium text-gray-700 hover:text-primary">
              Shop
            </Link>
            <Button
              onClick={() => scrollToSection('waitlist')}
              className="block w-full mt-1 bg-primary text-white hover:bg-primary/90"
            >
              Join Waitlist
            </Button>
            <Link href="/checkout">
              <Button variant="outline" className="mt-2 w-full flex items-center justify-center gap-2">
                <ShoppingCart className="h-5 w-5" /> View Cart
                {totalItems > 0 && (
                  <Badge 
                    className="ml-2 bg-primary text-white text-xs" 
                    variant="default"
                  >
                    {totalItems}
                  </Badge>
                )}
              </Button>
            </Link>
          </div>
        )}
      </div>
    </header>
  );
}
