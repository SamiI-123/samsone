import { Card, CardContent } from "@/components/ui/card";
import { Star } from "lucide-react";

interface TestimonialProps {
  initials: string;
  name: string;
  role: string;
  quote: string;
  rating: number;
}

function Testimonial({ initials, name, role, quote, rating }: TestimonialProps) {
  return (
    <Card className="bg-gray-50">
      <CardContent className="p-6">
        <div className="flex items-center mb-4">
          <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mr-4">
            <span className="text-primary font-medium">{initials}</span>
          </div>
          <div>
            <h4 className="font-medium text-gray-900">{name}</h4>
            <p className="text-gray-500 text-sm">{role}</p>
          </div>
        </div>
        <p className="text-gray-600 italic">{quote}</p>
        <div className="flex mt-4 text-primary">
          {[...Array(rating)].map((_, i) => (
            <Star key={i} className="h-5 w-5 fill-current" />
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

export default function Testimonials() {
  const testimonials = [
    {
      initials: "UA",
      name: "User A",
      role: "Early Tester",
      quote: "This device has changed my life! The ability to navigate confidently has given me a newfound sense of independence that I never thought possible.",
      rating: 5
    },
    {
      initials: "UB",
      name: "User B",
      role: "Beta Tester",
      quote: "Affordable and highly effective. The combination of the stick and glasses provides comprehensive coverage that has significantly reduced my daily navigation challenges.",
      rating: 5
    },
    {
      initials: "UC",
      name: "User C",
      role: "Prototype Tester",
      quote: "The emergency alert feature gives both me and my family peace of mind. I feel much safer knowing help is just a button press away if I ever need it.",
      rating: 5
    }
  ];

  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4 text-gray-900">What Our Users Say</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Hear from individuals who have experienced the Berhan difference.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Testimonial 
              key={index}
              initials={testimonial.initials}
              name={testimonial.name}
              role={testimonial.role}
              quote={testimonial.quote}
              rating={testimonial.rating}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
