import { Button } from "@/components/ui/button";
import { ChevronRight, ShoppingCart } from "lucide-react";
import { Link } from "wouter";

export default function Hero() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
      
      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  return (
    <section className="pt-24 pb-16 md:pt-32 md:pb-24 bg-gradient-to-r from-primary to-primary-800 text-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="w-full md:w-1/2 mb-10 md:mb-0 animate-fade-in">
            <h1 className="text-3xl md:text-5xl font-bold mb-4 leading-tight">
              Revolutionizing Mobility for the Visually Impaired
            </h1>
            <p className="text-lg md:text-xl mb-8 text-primary-100">
              The Berhan Smart Stick & Glasses combines AI-powered object detection with real-time audio feedback to enhance independence and safety.
            </p>
            <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4 mb-4">
              <Button 
                onClick={() => scrollToSection('waitlist')}
                variant="secondary"
                className="inline-flex justify-center items-center"
              >
                Join the Waitlist
                <ChevronRight className="h-5 w-5 ml-2" />
              </Button>
              <Button 
                onClick={() => scrollToSection('features')}
                variant="outline" 
                className="text-white border-white hover:bg-white/10"
              >
                Learn More
              </Button>
            </div>
            <div className="mt-4">
              <Link href="/shop">
                <Button 
                  variant="default"
                  className="bg-white text-primary hover:bg-gray-100 inline-flex items-center"
                >
                  <ShoppingCart className="h-5 w-5 mr-2" />
                  Shop Now
                </Button>
              </Link>
              <span className="ml-3 text-primary-100 text-sm">Pre-order available now!</span>
            </div>
          </div>
          <div className="w-full md:w-1/2 flex justify-center animate-slide-up">
            <div className="relative w-full max-w-md h-64 md:h-80 bg-primary-700 rounded-xl overflow-hidden shadow-2xl">
              <div className="absolute inset-0 flex items-center justify-center text-primary-200 text-lg">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                </svg>
                <div className="absolute left-0 right-0 bottom-0 p-4 bg-gradient-to-t from-primary-900 to-transparent">
                  <p className="text-white text-sm font-medium">Berhan Smart Stick & Glasses</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
