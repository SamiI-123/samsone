import { Card, CardContent } from "@/components/ui/card";
import { 
  LightbulbIcon, 
  Speaker, 
  Glasses, 
  Battery, 
  Target, 
  Watch 
} from "lucide-react";

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

function FeatureCard({ icon, title, description }: FeatureCardProps) {
  return (
    <Card className="bg-gray-50 hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center mb-4">
          {icon}
        </div>
        <h3 className="text-xl font-semibold mb-2 text-gray-900">{title}</h3>
        <p className="text-gray-600">{description}</p>
      </CardContent>
    </Card>
  );
}

export default function Features() {
  const features = [
    {
      icon: <LightbulbIcon className="h-6 w-6" />,
      title: "AI-powered Object Detection",
      description: "Detects obstacles like walls, poles, vehicles, and people using advanced sensors to provide real-time feedback."
    },
    {
      icon: <Speaker className="h-6 w-6" />,
      title: "Real-time Audio Feedback",
      description: "Alerts users through voice or vibration about nearby obstacles with clear, easy-to-understand notifications."
    },
    {
      icon: <Glasses className="h-6 w-6" />,
      title: "Smart Glasses Integration",
      description: "Enhances navigation by detecting objects at eye level and works together with the smart stick for complete coverage."
    },
    {
      icon: <Battery className="h-6 w-6" />,
      title: "Rechargeable Battery",
      description: "USB rechargeable with a long-lasting battery that provides extended usage for outdoor and indoor travel."
    },
    {
      icon: <Target className="h-6 w-6" />,
      title: "Emergency Alert System",
      description: "Sends an SOS alert to family or emergency contacts, ensuring safety in case of accidents or emergencies."
    },
    {
      icon: <Watch className="h-6 w-6" />,
      title: "Lightweight & Durable",
      description: "Comfortable, waterproof, and easy to carry with a compact, foldable design ideal for travel and daily commuting."
    }
  ];

  return (
    <section id="features" className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4 text-gray-900">Smart Features for Enhanced Mobility</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Our innovative technology provides comprehensive support for daily navigation and independence.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <FeatureCard 
              key={index}
              icon={feature.icon}
              title={feature.title}
              description={feature.description}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
