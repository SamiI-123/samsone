from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt

app = Flask(__name__)
app.config['SECRET_KEY'] = 'supersecretkey'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)

# Database Models
class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Float, nullable=False)
    description = db.Column(db.Text, nullable=False)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)

# Routes
@app.route('/')
def home():
    products = Product.query.all()
    return render_template('shop.html', products=products)

@app.route('/add_to_cart/<int:product_id>')
def add_to_cart(product_id):
    cart = session.get('cart', {})
    cart[product_id] = cart.get(product_id, 0) + 1
    session['cart'] = cart
    return jsonify({'message': 'Added to cart', 'cart': cart})

@app.route('/cart')
def view_cart():
    cart = session.get('cart', {})
    products = {p.id: p for p in Product.query.all()}
    cart_items = [{'name': products[int(pid)].name, 'price': products[int(pid)].price, 'quantity': qty}
                  for pid, qty in cart.items()]
    total_price = sum(item['price'] * item['quantity'] for item in cart_items)
    return render_template('cart.html', cart=cart_items, total_price=total_price)

@app.route('/checkout', methods=['POST'])
def checkout():
    session.pop('cart', None)  # Clear cart after checkout
    return jsonify({'message': 'Order placed successfully!'})

if __name__ == '__main__':
    db.create_all()  # Create database tables
    app.run(debug=True)
