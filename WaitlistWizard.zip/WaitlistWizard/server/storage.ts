import { users, type User, type InsertUser, type WaitlistEntry, type InsertWaitlistEntry } from "@shared/schema";

// Storage interface definition
export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Waitlist methods
  createWaitlistEntry(entry: InsertWaitlistEntry): Promise<WaitlistEntry>;
  getWaitlistCount(): Promise<number>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private waitlist: Map<number, WaitlistEntry>;
  private userId: number;
  private waitlistId: number;

  constructor() {
    this.users = new Map();
    this.waitlist = new Map();
    this.userId = 1;
    this.waitlistId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  async createWaitlistEntry(insertEntry: InsertWaitlistEntry): Promise<WaitlistEntry> {
    // Check if email already exists
    const existingEntry = Array.from(this.waitlist.values()).find(
      (entry) => entry.email === insertEntry.email,
    );
    
    if (existingEntry) {
      throw new Error("Email already exists in waitlist (unique constraint)");
    }
    
    const id = this.waitlistId++;
    // Ensure wantsUpdates is never undefined (matching WaitlistEntry type)
    const entry: WaitlistEntry = { 
      ...insertEntry, 
      id, 
      wantsUpdates: insertEntry.wantsUpdates ?? true,
      createdAt: new Date() 
    };
    
    this.waitlist.set(id, entry);
    return entry;
  }
  
  async getWaitlistCount(): Promise<number> {
    return this.waitlist.size;
  }
}

export const storage = new MemStorage();
