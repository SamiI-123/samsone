import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { waitlistSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Waitlist signup endpoint
  app.post("/api/waitlist", async (req, res) => {
    try {
      const validatedData = waitlistSchema.parse(req.body);
      const entry = await storage.createWaitlistEntry(validatedData);
      return res.status(201).json({ 
        success: true, 
        message: "Successfully joined waitlist", 
        entry 
      });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ 
          success: false, 
          message: validationError.message 
        });
      } else if (error instanceof Error && error.message.includes("unique")) {
        return res.status(409).json({ 
          success: false, 
          message: "This email is already on our waitlist" 
        });
      }
      
      return res.status(500).json({ 
        success: false, 
        message: "An error occurred while joining the waitlist" 
      });
    }
  });
  
  // Get waitlist statistics
  app.get("/api/waitlist/stats", async (_req, res) => {
    try {
      const count = await storage.getWaitlistCount();
      return res.status(200).json({ count });
    } catch (error) {
      return res.status(500).json({ 
        success: false, 
        message: "An error occurred while fetching waitlist statistics" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
